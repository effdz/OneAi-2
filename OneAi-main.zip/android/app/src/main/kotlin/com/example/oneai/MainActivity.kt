package com.example.oneai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    // Tidak perlu menambahkan kode tambahan
}